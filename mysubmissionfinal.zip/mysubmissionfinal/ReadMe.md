


Prequiresits

1.OPencv for reading and writing images
2.Menpofit for Supervised decent method
3.LBP_top algortihm for feature extraction
4.SKlearn for SVC with chi-squared kernel for classification





