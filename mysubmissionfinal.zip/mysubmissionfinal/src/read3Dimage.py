#use intraface library for face alignment
 
 
 import menpofit
 import bob.ip.base
 import pandas as pd

 
 class read3Dimage:
 
    def image_to_df(path):
 sdm_im = menpofit.sdm.SDM(images)
 
 lbp = LBPTOP(sdm_im)
 df = pd.DataFrame(lbp)
 
   return df
	
	

